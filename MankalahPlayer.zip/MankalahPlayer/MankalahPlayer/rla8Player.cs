﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Mankalah
{
    /*****************************************************************
        * A Mankalah player.  This is the base class for players.
        * You'll derive a player from this base. Be sure your player
        * works correctly both as TOP and as BOTTOM.
        *****************************************************************/
    class rla8Player : Player
    {
        // constructor
        public rla8Player(Position pos, int timeLimit)
            : base(pos, "rla8Player", timeLimit) { }

        // getImage returns an image of the human
        public override String getImage()
        {
            return "picture.png";
        }

        // choosemove() calls the minimax() function so that it can find its move, and
        // return the move that is calculated best.
        public override int chooseMove(Board b)
        {
            Stopwatch stopwatch = new Stopwatch();
            MoveResult move = new MoveResult(0, 0, false);
            stopwatch.Start();
            int i = 1;
            
            // try block to check if the maximum time hasn't elapsed, and using the last move
            try
            {
                while (!move.isEndGame())
                {
                    move = minimax(b, i++, stopwatch, Int32.MinValue, Int32.MaxValue);
                }
            }
            // Throw an exception if time has elapsed and return the move.
            catch (MoveTimedOutException) {}
            return move.getMove();
        }
        // The overriden evaluate() function checks for factors of the board, 
        public override int evaluate(Board b)
        {
            // heuristics
            int score = b.stonesAt(13) - b.stonesAt(6); // amount in your base - opponents base
            int stonesTotal = 0; // saves the number of stones in move
            int capturesTotal = 0; // number of points that would be captured
            int goAgainsTotal = 0; // go-again moves
            int opponentWinning = 0; // what the opponent is winning

            //heurestics calculator for the TOP player
            for (int i = 7; i <= 12; i++)
            {
                // add the stones
                stonesTotal += b.stonesAt(i);
                // go-again increment
                if (b.stonesAt(i) - (13 - i) == 0)
                    goAgainsTotal += 1;

                // capture stones add
                int target = i + b.stonesAt(i);
                if (target < 13)
                {
                    int targetStones = b.stonesAt(target);
                    if (b.whoseMove() == Position.Top)
                    {
                        if (targetStones == 0 && b.stonesAt(13 - target - 1) != 0) capturesTotal += b.stonesAt(13 - target - 1);
                    }
                }
            }

            // heurestics calculation for the bottom player
            for (int i = 0; i <= 5; i++)
            {
                // subtract all the stones in the bottom row
                stonesTotal -= b.stonesAt(i);
                // go-again moves addition
                if (b.stonesAt(i) - (6 - i) == 0) goAgainsTotal -= 1;

                // subtract all of the capture stones
                int target = i + b.stonesAt(i);
                if (target < 6)
                {
                    int targetStones = b.stonesAt(target);
                    if (b.whoseMove() == Position.Bottom)
                    {
                        if (targetStones == 0 && b.stonesAt(13 - target - 1) != 0) capturesTotal -= b.stonesAt(13 - target - 1);
                    }
                }
            }

            // Give points to either min or max based on your position when the opposition is winning
            if (b.whoseMove() == Position.Top)
            {
                // give points to min if you are on top
                if (b.stonesAt(6) > 24) opponentWinning -= 3;
            }
            else
            {
                // give points to max of your are at bottom
                if (b.stonesAt(13) > 24) opponentWinning += 3;
            }

            // add the scores and return it
            score += stonesTotal + capturesTotal + opponentWinning + goAgainsTotal;
            return score;
        }
        // customized gloat function
        public override String gloat()
        {
            return "You could not live with your own failure. Where did that lead you?";
        }

        // The function minimax() return both the best move and the score for that move. I
        private MoveResult minimax(Board b, int d, Stopwatch w, int alpha, int beta)
        {
            // check to see if the time limit is elapsed
            if (w.ElapsedMilliseconds > getTimePerMove()) throw new MoveTimedOutException();
            // base case
            if (b.gameOver() || d == 0)
            {
                return new MoveResult(0, evaluate(b), b.gameOver());
            }
            // variable initialization
            int bestMove = 0;
            int bestValue;
            bool gameCompleted = false;
            // check if TOP is max
            if (b.whoseMove() == Position.Top) 
            {
                // minimum value to begin, so that it can only get better by growing larger
                bestValue = Int32.MinValue;
                for (int move = 7; move <= 12 && alpha < beta; move++)
                {
                    if (b.legalMove(move))
                    {
                        Board b1 = new Board(b);                               // create a new board
                        b1.makeMove(move, false);                             // make the move and find the value of that move
                        MoveResult val = minimax(b1, d - 1, w, alpha, beta);   
                        if (val.getScore() > bestValue)                          // if the value is best, save it
                        {
                            bestValue = val.getScore();
                            bestMove = move;
                            // take notice of the game's current progress
                            gameCompleted = val.isEndGame();
                        }
                        // alpha beta pruning
                        if (bestValue > alpha)
                        {
                            alpha = bestValue;
                        }
                    }
                }
            }
            // check all the the moves that bottom could make, and act as if it is the MIN in minimax
            else  // check if BOTTOM is min
            {
                //minimum value to begin, so that it can only get better by growing smaller
                bestValue = Int32.MaxValue;
                for (int move = 0; move <= 5 && alpha < beta; move++)
                {
                    if (b.legalMove(move))
                    {
                        Board b1 = new Board(b);                               // create a new board
                        b1.makeMove(move, false);                              // make the move and find the value of that move
                        MoveResult val = minimax(b1, d - 1, w, alpha, beta);   
                        if (val.getScore() < bestValue)                          // if the value is best, save it
                        {
                            bestValue = val.getScore();
                            bestMove = move;
                            // take notice of the game's current progress
                            gameCompleted = val.isEndGame();
                        }
                        // alpha beta pruning
                        if (bestValue < beta)
                        {
                            beta = bestValue;
                        }
                    }
                }
            }
            return new MoveResult(bestMove, bestValue, gameCompleted);
        }
    }

    /*****************************************************************/
    /* MoveReeult stores the results of the minimax 
    /* function. 
    /*****************************************************************/

    class MoveResult
    {
        private int bestMove;
        private int bestScore;
        private bool endGame;
        public MoveResult(int move, int score, bool end)
        {
            bestMove = move;
            bestScore = score;
            endGame = end;
        }

        public int getMove() { return bestMove; }

        public int getScore() { return bestScore; }

        public bool isEndGame() { return endGame; }
    }
    class MoveTimedOutException : Exception { }

}