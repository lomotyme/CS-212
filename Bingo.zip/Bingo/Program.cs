﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace Bingo
{
    class Program
    {
        private static RelationshipGraph rg;

        // Read RelationshipGraph whose filename is passed in as a parameter.
        // Build a RelationshipGraph in RelationshipGraph rg
        private static void ReadRelationshipGraph(string filename)
        {
            rg = new RelationshipGraph();                           // create a new RelationshipGraph object

            string name = "";                                       // name of person currently being read
            int numPeople = 0;
            string[] values;
            Console.Write("Reading file " + filename + "\n");
            try
            {
                string input = System.IO.File.ReadAllText(filename);// read file
                input = input.Replace("\r", ";");                   // get rid of nasty carriage returns 
                input = input.Replace("\n", ";");                   // get rid of nasty new lines
                string[] inputItems = Regex.Split(input, @";\s*");  // parse out the relationships (separated by ;)
                foreach (string item in inputItems)
                {
                    if (item.Length > 2)                            // don't bother with empty relationships
                    {
                        values = Regex.Split(item, @"\s*:\s*");     // parse out relationship:name
                        if (values[0] == "name")                    // name:[personname] indicates start of new person
                        {
                            name = values[1];                       // remember name for future relationships
                            rg.AddNode(name);                       // create the node
                            numPeople++;
                        }
                        else
                        {
                            rg.AddEdge(name, values[1], values[0]); // add relationship (name1, name2, relationship)

                            // handle symmetric relationships -- add the other way
                            if (values[0] == "spouse" || values[0] == "hasFriend")
                                rg.AddEdge(values[1], name, values[0]);

                            // for parent relationships add child as well
                            else if (values[0] == "parent")
                                rg.AddEdge(values[1], name, "child");
                            else if (values[0] == "child")
                                rg.AddEdge(values[1], name, "parent");
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.Write("Unable to read file {0}: {1}\n", filename, e.ToString());
            }
            Console.WriteLine(numPeople + " people read");
        }

        // Show the relationships a person is involved in
        private static void ShowPerson(string name)
        {
            GraphNode n = rg.GetNode(name);
            if (n != null)
                Console.Write(n.ToString());
            else
                Console.WriteLine("{0} not found", name);
        }

        // Show a person's friends
        private static void ShowFriends(string name)
        {
            GraphNode n = rg.GetNode(name);
            if (n != null)
            {
                Console.Write("{0}'s friends: ", name);
                List<GraphEdge> friendEdges = n.GetEdges("hasFriend");
                foreach (GraphEdge e in friendEdges)
                {
                    Console.Write("{0} ", e.To());
                }
                Console.WriteLine();
            }
            else
                Console.WriteLine("{0} not found", name);
        }

        // Show a particular relationship graph's orphans
        private static void ShowOrphans()
        {
            int num_orphans = 0;     //count the number of orphans in a Relationship Graph
            List<GraphNode> storeOrphan = new List<GraphNode>();     //Create a new list to store the Orphans in

            foreach (GraphNode node in rg.nodes)
            {      //Loop through the list of the Relationship Graph nodes
                List<GraphEdge> parentEdges = node.GetEdges("hasParent");
                if (parentEdges.Count == 0)
                {       //if the orphans have no parents
                    storeOrphan.Add(node);           //Add the node to the Orphan List
                    num_orphans++;                 
                }
            }

            string orphan_number = Convert.ToString(num_orphans);

            foreach (GraphNode node in storeOrphan)      //printing out the name of the orphan
            {
                Console.Write(node.Name() + '\n');
            }

            Console.Write("There are " + orphan_number + " orphans in the Graph Relationship.");   
        }

        //Function for showing an individual's descendants
        private static void ShowDescendants(string name)
        {
            int countGeneration = 0;
            GraphNode node = rg.GetNode(name);      //individual's relationship graph node getter                               

            //If the individual does not exist in the graph
            if (node == null)
            {
                Console.Write("{0} not found\n", name);
            }

            else if (node.GetEdges("hasChild").Count == 0)       //If the individual does not have a child
            {
                Console.Write("{0} has no descendants\n", name);
            }

            //If the individual has children, list out the descendants of the individual
            else
            {
                List<GraphEdge> descendantsList = node.GetEdges("hasChild");        //Get the edges hasChild of the individual

                List<GraphNode> nextDescendants = new List<GraphNode>();            //Create two new lists of GraphNodes, one for the current and one for the next descendant generation 
                List<GraphNode> currentDescendants = new List<GraphNode>();              

                foreach (GraphEdge edge in descendantsList)                         //For every edge hasChild, add the node that the edge is directed towards
                {                                                                       //to the current descendants list of individuals
                    currentDescendants.Add(rg.GetNode(edge.To()));
                }

                while (currentDescendants.Count > 0)                                //As long as the currentDescendants List is not zero
                {

                    //countGeneration being 0 represents children, and 1 represents grandchildren, incremental count adds great. 
                    if (countGeneration == 0)
                    {
                        Console.Write(node.Name() + " Children:\n");
                    }

                    else if (countGeneration == 1)
                    {
                        Console.Write(node.Name() + " Grandchildren:\n");
                    }

                    else
                    {
                        Console.Write(node.Name());
                        for (int i = 0; i < countGeneration; i++)
                        {
                            Console.Write(" Great");
                        }
                        Console.Write(" GrandChildren:\n");

                    }

                    //For each node in the current descendants list
                    foreach (GraphNode descendant in currentDescendants)
                    {
                        Console.Write("{0}\n", descendant.Name());              //Write out the name of the descendant to the console
                        descendantsList = descendant.GetEdges("hasChild");      //Get a list of the edges hasChild from that descendant

                        foreach (GraphEdge edge1 in descendantsList)            //For each of those edges hasChild of the current descendant
                        {
                            nextDescendants.Add(rg.GetNode(edge1.To()));    //Add the node that the edge hasChild is directed towards
                        }
                    }

                    currentDescendants = nextDescendants;                       //next descendants become current descendants
                    nextDescendants = new List<GraphNode>();                    //next descendants become emoty for future descendants
                    countGeneration++;                                         //generation increment for future genenration
                }
            }
        }

        // Find the shortest path of relationships between two people
        private static void Bingo(string first_person, string last_person)
        {
            //Let the user know if the first and last person are the same person
            if (first_person == last_person)
            {
                Console.Write(first_person + " and " + last_person + " are the same.\n");
            }

            else
            {
                int min_depth = 0;      //min_depth evaluates the shortest number of times from first person to last person

                Dictionary<string, Boolean> dictionary = new Dictionary<string, Boolean>();     //cheking if a node has already been visited with new dictionary
                foreach (GraphNode node_ in rg.nodes)
                    dictionary.Add(node_.Name(), false);

                Queue<string> q = new Queue<string>();      
                dictionary[first_person] = true;            //first person node has been visited
                q.Enqueue(first_person);                    //appends the first person to the queue

                //while the queue is not empty
                while (q.Count > 0)
                {
                    string next_name = q.Dequeue();                          //Remove next element in the queue
                    GraphNode node_one = rg.GetNode(next_name);
                    List<GraphEdge> AdjacentEdges = node_one.GetEdges();
                    min_depth++;                                        //increase the depth of path taken to reach last person

                    //Check each GraphEdge coming out of the current node
                    foreach (GraphEdge edge in AdjacentEdges)
                    {

                        if (next_name == last_person)                         //If the next name, which is the current node, and the last_person are the same, exit the while loop
                            break;

                        if (dictionary[edge.To()] == false)
                        {
                            dictionary[edge.To()] = true;                   //Update the visited dictionary
                            q.Enqueue(edge.To());                           //append to the queue
                        }
                    }

                }

                List<GraphNode> list_nodes = new List<GraphNode>();        //create new lists for the edges and nodes to last person
                List<GraphEdge> list_edges = new List<GraphEdge>();

                Dictionary<string, Boolean> dictionary2 = new Dictionary<string, Boolean>();
                foreach (GraphNode node_ in rg.nodes)
                    dictionary2.Add(node_.Name(), false);

                int stack_depth_counter = 0;          // counter records how far to go in the DFS
                Stack<GraphNode> stack_nodes = new Stack<GraphNode>();  //new stack
                stack_nodes.Push(rg.GetNode(first_person));             //Push the first person onto the stack

                while (true)
                {   
                    //while the stack in not empty
                    while (stack_nodes.Count > 0)                               
                    {
                        GraphNode node_one = stack_nodes.Pop();             //next element pop
                        list_nodes.Add(node_one);                           //append to list

                        List<GraphEdge> edges_list = node_one.GetEdges();
                        list_edges.Add(edges_list[0]);

                        foreach (GraphEdge edge_two in edges_list)
                        {
                            stack_nodes.Push(rg.GetNode(edge_two.To()));       //Push each node coming off the edges to the stack
                        }

                        stack_depth_counter++;
                        if (stack_depth_counter == min_depth)           //exit while loop if the two depth counters are the same
                            break;
                    }

                    //if the first node is equal to the first person, and the last node equal to the last person
                    if (list_nodes[0] == rg.GetNode(first_person) && list_nodes[min_depth - 1] == rg.GetNode(last_person))
                    {
                        break;
                    }
                }

                //prints out the relationship between the first and last person
                int i = 0;
                foreach (GraphNode NODE in list_nodes)
                {
                    GraphEdge edge_label = list_edges[i];
                    Console.Write(NODE.Name() + edge_label.Label() + list_nodes[i + 1] + "\n");
                    i++;
                }
            }
        }

        // accept, parse, and execute user commands
        private static void commandLoop()
        {
            string command = "";
            string[] commandWords;
            Console.Write("Welcome to Harry's Dutch Bingo Parlor!\n");

            while (command != "exit")
            {
                Console.Write("\nEnter a command: ");
                command = Console.ReadLine();
                commandWords = Regex.Split(command, @"\s+");        // split input into array of words
                command = commandWords[0];

                if (command == "exit")
                    ;                                               // do nothing

                // read a relationship graph from a file
                else if (command == "read" && commandWords.Length > 1)
                    ReadRelationshipGraph(commandWords[1]);

                // show information for one person
                else if (command == "show" && commandWords.Length > 1)
                    ShowPerson(commandWords[1]);

                // show all the friends of a person
                else if (command == "friends" && commandWords.Length > 1)
                    ShowFriends(commandWords[1]);

                //  show all the people who are orphans (have no parents)
                else if (command == "orphans")
                    ShowOrphans();

                // show all the descendents of an individual
                else if (command == "descendants" && commandWords.Length > 1)
                    ShowDescendants(commandWords[1]);

                // find the shortest path of relationships between two people
                else if (command == "bingo" && commandWords.Length > 1)
                Bingo(commandWords[1], commandWords[2]);


                // dump command prints out the graph
                else if (command == "dump")
                    rg.Dump();

                // illegal command
                else
                    Console.Write("\nLegal commands: read [filename], dump, show [personname],\n  friends [personname], exit\n");
            }
        }

        static void Main(string[] args)
        {
            commandLoop();
        }
    }
}
